import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Home from "./pages/Admin";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AddUser from "./users/Signup";
import Signin from "./users/Signin";
import DiscussionComponent from "./pages/DiscussionComponent";


function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/adduser" element={<AddUser />} />
          <Route exact path="/signin" element={<Signin />} />
          <Route exact path="/community-chat" element={<DiscussionComponent />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
