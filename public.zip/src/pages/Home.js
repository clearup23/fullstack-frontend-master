import React from "react";
import Navbar2 from "../layout/Navbar2";
// import CommunityChat from "./CommunityChat";

export default function Home() {
  return (
    <div>
      <Navbar2 />
    </div>
  );
}
